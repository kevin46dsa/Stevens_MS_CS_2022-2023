package edu.stevens.cs522.hello;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ShowActivity extends AppCompatActivity {

    public final static String Message_KEY = "message";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);
        Intent intent=getIntent();
        String message = intent.getStringExtra(Message_KEY);
        TextView textView=new TextView(this);
        textView.setTextSize(40);
        textView.setText(message);

        ViewGroup layout=(ViewGroup) findViewById(R.id.display_message);
        layout.addView(textView);
    }
}
